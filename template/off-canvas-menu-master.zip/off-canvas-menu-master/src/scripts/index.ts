import "../styles/index.scss";
import OffCanvasMenu from "./OffCanvasMenu";

// TODO: Close other submenus not working with menu item nesting > 2
const menu = new OffCanvasMenu();

menu.init();
